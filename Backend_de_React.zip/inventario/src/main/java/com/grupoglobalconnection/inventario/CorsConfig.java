/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.grupoglobalconnection.inventario;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 *
 * @author Leandro
 */

@Configuration
public class CorsConfig implements WebMvcConfigurer {
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")  // Permitir CORS en todas las rutas
                .allowedOrigins("http://localhost:3000")  // Permitir solicitudes desde el frontend en el puerto 3000
                .allowedMethods("GET", "POST", "PUT", "DELETE")  // Permitir solo estos métodos
                .allowedHeaders("*");  // Permitir todos los encabezados
    }
}
